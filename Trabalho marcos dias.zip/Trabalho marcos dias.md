﻿**IFTO – Campus Dianópolis** 

**Estudantes: Beatriz Soares, Maurício Dias** 

**Em um controlador como o que construímos, como garantir que somente requisições válidas serão repassadas ao banco de dados?** 

Existem várias maneiras de fazermos uma validação em uma API, mas a que vamos utilizar 

é por meio da biblioteca express.validator. O express.validator é uma biblioteca que agrega 

conjuntos de middlewares de validação de dados. nos deixa criar campos de validações das 

informações como validação de email e senha de um formulário 

Para começar o processo temos que instalar o express.validator, que é feito por npm: 

![](Aspose.Words.7414d73f-62b4-4bbb-a0ba-3ec481e92b6f.001.png)

Após isso usamos uma rota para importar o body e validationResult. E em seguida é necessário colocar a validação como um middleware na request, e é possível fazer isso utilizando um array antes do request e response, dessa forma:  

![](Aspose.Words.7414d73f-62b4-4bbb-a0ba-3ec481e92b6f.002.jpeg)

Os campos body irão servir para validar os dados de entrada e o validationResult vai conter o resultado da entrada. Referências 

[https://youtu.be/08rRhRL23u4 ](https://youtu.be/08rRhRL23u4) 

**Como responder ao usuário em caso de uma entrada incorreta?** 

Para o caso de que não se tenha encontrado o valor de entrada é simples. Utilizando o comando abaixo assim que não encontrado o valor, será retornado ao usuário uma mensagem em resposta. 

app.post('/user', [ 

`    `//validação dos dados 

`    `body('name').notEmpty().withMessage("O campo nome é obrigatório") ], (req, res) => { 

`    `// caso encontre erros, ficará nessa variável errors 

`    `const errors = validationResult(req); 

`    `if (!errors.isEmpty()) { 

`        `return res.status(400).json({ errors: errors.array() }); 

`    `} 

Com isso, a resposta do erro será essa: 

![](Aspose.Words.7414d73f-62b4-4bbb-a0ba-3ec481e92b6f.003.png)

Referências: 

[https://programandosolucoes.dev.br/2020/11/10/valida-api-express- validator/#Personalizar_mensagem_de_erro ](https://programandosolucoes.dev.br/2020/11/10/valida-api-express-validator/#Personalizar_mensagem_de_erro)

https://www.youtube.com/watch?v=FlH\_rw8\_B0c 
